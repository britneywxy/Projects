package graphs;

import java.util.*;

public class ToposortDAGSolver<V> implements ShortestPathSolver<V> {
    private final Map<V, Edge<V>> edgeTo;
    private final Map<V, Double> distTo;
    private final V start;

    public ToposortDAGSolver(Graph<V> graph, V start) {
        this.edgeTo = new HashMap<>();
        this.distTo = new HashMap<>();
        this.start = start;

        // TODO: Your code here!
        // DFS:Post order(recursion)
        // reversed the order --> toposort
        List<V> postOrder = new ArrayList<>();
        Set<V> visited = new HashSet<>();
        postOrderDFS(graph, postOrder, visited, start);
        Collections.reverse(postOrder);

        // Dijkstra relaxation step
        edgeTo.put(start, null);
        distTo.put(start, 0.0);
        for(V from: postOrder){
            for (Edge<V> e : graph.neighbors(from)) {
                    V to = e.to();
                    double oldDist = distTo.getOrDefault(to, Double.POSITIVE_INFINITY);
                    double newDist = distTo.get(from) + e.weight();
                    if (newDist < oldDist) {
                        edgeTo.put(to, e);
                        distTo.put(to, newDist);
                    }
            }
        }
    }

    // TODO: Your code here!
    public void postOrderDFS(Graph<V> graph, List<V> postOrder, Set<V> visited, V curr){
        visited.add(curr);
        for(Edge<V> edge: graph.neighbors(curr)){
            V to = edge.to();
            if(!visited.contains(to)){
                postOrderDFS(graph,postOrder,visited,to);
            }
        }
        postOrder.add(curr);
    }

    public List<V> solution(V goal) {
        List<V> path = new ArrayList<>();
        V curr = goal;
        path.add(curr);
        while (edgeTo.get(curr) != null) {
            curr = edgeTo.get(curr).from();
            path.add(curr);
        }
        Collections.reverse(path);
        return path;
    }
}
